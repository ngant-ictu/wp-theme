(function($) {
	"use strict";
	$(document).ready(function(){
		$( '.project-portfolio' ).each(function(){
			var button = $('.pagination-ajax > button');
			var loadmore_style  = button.data( 'loadmore_style' );
			var $this 			= $(this);
			var $id 			= this.id;
			var $pf_id 			= ('#' + this.id );
			var $ajax_url 		= ya_portfolio.ajax_url;
			var $ya_style 		= $this.data('style');
			var $layout 		= $this.data('layout');
			var $categories 	= $this.data('categories');
			var $max_page 		= $this.data('max_page');
			var $attributes 	= $this.data('attributes');
			var $number 	    = $this.data('number');
			var $offset 		= $this.data('offset');
			var $orderby 		= $this.data('orderby');
			var $order 			= $this.data('order');
			var $container_id 	= $('#container_'+ $id);
			var $tab_id 		= $('#tab_'+ $id);
			var $page = 2;
			var loading = false;
			var scrollHandling = {
			    allow: true,
			    reallow: function() {
			        scrollHandling.allow = true;
			    },
			    delay: 400 /* milliseconds) adjust to the highest acceptable value */
			};			
			var $container 		= $container_id; //The ID for the list with all the blog posts
			if( $ya_style == 'fitRows' ){
				$container.imagesLoaded().progress( function() {
					$container.isotope({ //Isotope options, 'item' matches the class in the PHP
						layoutMode : 'fitRows'
					});
				});
			}else{
				$container.imagesLoaded().progress( function() {
					$container.isotope({ //Isotope options, 'item' matches the class in the PHP
						layoutMode : 'masonry',
						percentPosition: true,
						masonry: {
						  columnWidth: '.portfolio-item'
						}
					});
				});
			}
		 
			//Add the class selected to the item that is clicked, and remove from the others
			var $optionSets = $tab_id,
			$optionLinks = $optionSets.find('li');
			$optionLinks.click(function(){
				var $this = $(this);
				// don't proceed if already selected
				if ( $this.hasClass('selected') ) {
				  return false;
				}
				var $optionSet = $this.parents($tab_id);
				$optionSets.find('.selected').removeClass('selected');
				$this.addClass('selected');
			 
				//When an item is clicked, sort the items.
				 var selector = $(this).attr('data-portfolio-filter');
				$container.isotope({ filter: selector });
				return false;
			});
			
			var $btn_loadmore = $('.btn-loadmore');

	        if( loadmore_style == 1 ){
				$(window).scroll(function(){
					if( ! loading && scrollHandling.allow ) {
						scrollHandling.allow = false;
						setTimeout(scrollHandling.reallow, scrollHandling.delay);
						var offset = $(button).offset().top - $(window).scrollTop();	
						if( $max_page < $page ){
							button.addClass( 'loaded' );
						}
						
						if( 1000 > offset && $max_page >= $page ) {
							_product_loadmore_ajax();
						}
					}
				});			
	        }else{
				$btn_loadmore.on("click", function(){
	                _product_loadmore_ajax();
				});
			}

            function _product_loadmore_ajax(){
			    loading = true;
				$(this).addClass('btn-loading');
				
				jQuery.ajax({
					 type: "POST",
					 url: $ajax_url,
					 data: ({
						action : "sw_project_ajax",
						catid  : $categories,
						numb   : $number,
						orderby: $orderby,
						order : $order,
						page : $page,
						style : $ya_style,
						layout : $layout,
						attributes: $attributes
					}),
					 success: function(data) {
						var $newItems = $(data);
						if( $newItems.length > 0 ){
							$newItems.imagesLoaded( function(){
								$container_id.isotope('reloadItems').isotope("insert",$newItems);
							});
							$page = $page + 1;
							loading = false;
							$btn_loadmore.removeClass('btn-loading');
							if( $newItems.length < $number ){
								$btn_loadmore.addClass( 'loaded' );
							}
							if( $max_page <  $page){
								$btn_loadmore.addClass( 'loaded' );
							}
							
						}else{
							$btn_loadmore.removeClass('btn-loading').addClass( 'loaded' );
						}
					 }
				 });					
            }			

		});		
	});
})(jQuery);