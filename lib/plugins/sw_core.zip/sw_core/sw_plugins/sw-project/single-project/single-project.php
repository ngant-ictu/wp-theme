<?php get_header(); ?>
<?php kontruk_breadcrumb_title(); ?>
<?php 
	$kontruk_single_style = swg_options( 'project_single_style' );
	if( empty( $kontruk_single_style ) || $kontruk_single_style == 'default' ){ 
		include( 'content-single-project.php' );
	}
	else{
		include( 'content-single-project-' . $kontruk_single_style .'.php' );
	}
?>
<?php get_footer(); ?>