<div class="container">
	<div class="row sidebar-row">
		<div class="single main">
			<?php while (have_posts()) : the_post(); ?>
				<?php 
					global $post; 
					$pr_location 	 = get_post_meta( $post->ID, 'pr_location', true );
					$pr_year = get_post_meta( $post->ID, 'pr_year', true );
				?>
				<div <?php post_class(); ?>>
					<!-- Entry Gallery -->
					<?php if( count( sw_get_project_gallery( $post->ID ) ) ) : ?>
						<div id="<?php echo esc_attr( 'single_gallery' . $post->ID ); ?>" class="responsive-slider gallery-project loading" data-lg="1" data-md="1" data-sm="1" data-xs="1" data-mobile="1" data-speed="1000" data-scroll="1" data-interval="4000"  data-autoplay="false">
							<div class="slider responsive">	
							<?php 
								$galleries = sw_get_project_gallery( $post->ID );
								foreach( $galleries as $gallery ) {
								$image = wp_get_attachment_image_src( $gallery, 'full' );
							?>
								<div class="item-gallery">
									<a class="gallery-single-item" rel="group-gallery" href="<?php echo esc_url( $image[0] ); ?>"><?php echo wp_get_attachment_image( $gallery, 'full', false, array() ); ?></a>
								</div>
							<?php } ?>
							</div>
						</div>
					<?php endif; ?>
					<div class="clear"></div>
					<!-- Entry Top -->
					<div class="entry-top clearfix">						
						<div class="entry-left col-md-9 col-sm-8 col-xs-12">
							<h2 class="entry-single-title"><?php the_title(); ?></h2>
							<div class="entry-content-single">
								<?php the_content(); ?>
							</div>
							<?php kontruk_get_social() ?>
						</div>
						<div class="entry-meta col-md-3 col-sm-4 col-xs-12">
							<h3><?php esc_html_e( 'Project Info', 'sw_core' ) ?></h3>
							<?php echo ( $pr_location ) ? '<div class="meta-item"><p>' . esc_html__( 'Location', 'sw_core' ) . '</p> <span>'. esc_html( $pr_location ) .'</span></div>' : ''; ?>
							<?php echo ( $pr_year ) ? '<div class="meta-item"><p>' . esc_html__( 'Year', 'sw_core' ) . '</p> <span>'. esc_html( $pr_year ) .'</span></div>' : ''; ?>
							<?php echo get_the_term_list( $post->ID, 'project_cat', '<div class="meta-item"><p>' . esc_html__( 'Category', 'sw_core' ) . '</p>', ', ', '</div>' ); ?>
							<?php echo get_the_term_list( $post->ID, 'project_tag', '<div class="meta-item"><p>' . esc_html__( 'Tags', 'sw_core' ) . '</p>', ', ', '</div>' ); ?>
						</div>
					</div>
					<div class="clear"></div>
					
					<!-- Relate Post -->
					<?php 
						global $post;
						global $related_term;
						$pr_location 	 = get_post_meta( $post->ID, 'pr_location', true );
						$pr_year = get_post_meta( $post->ID, 'pr_year', true );
						$categories = get_the_terms( $post->ID, 'project_cat' );							
						$category_ids = array();
						foreach($categories as $individual_category) {$category_ids[] = $individual_category->term_id;}
						if ($categories) {
							$related = array(
							'post__not_in' => array( $post->ID ),
							'showposts'=> 4,
							'post_type'	=> 'project',
							'orderby'	=> 'name',	
							'ignore_sticky_posts'=> 1,
							'tax_query' => array(
								array(
									'taxonomy' => 'project_cat',
									'field'    => 'term_id',
									'terms'    => $category_ids,
								)
							)
						);
					?>
					<div class="single-project-relate clearfix">
						<h3><?php esc_html_e( 'Related Projects', 'sw_core' ); ?></h3>
						<div id="<?php echo esc_attr( 'single_project' . $post->ID ); ?>" class="related-wrapper responsive-slider loading" data-lg="3" data-md="3" data-sm="2" data-xs="1" data-mobile="1" data-speed="1000" data-scroll="1" data-interval="4000" data-autoplay="false">
							<div class="slider responsive">	
							<?php 
							$related_term = new WP_Query( $related );
							while( $related_term -> have_posts() ) : $related_term -> the_post();
							global $post;
								?>
								<div class="post item-project">
									<?php 
										$feat_image_url2 = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
										if ( $feat_image_url2 ){ 
									?>
									<div class="item-relate-img">
										<a href="<?php echo get_permalink($post->ID)?>" title="<?php the_title_attribute(); ?>">
										<?php 								
											$width  = 370;
											$height = 400;
											$image = sw_image_resize( $feat_image_url2, $width, $height, true );
											echo '<img src="'. esc_url( $image['url'] ) .'" alt="'. esc_attr( $post->post_title ) .'">';
										?>
										</a>
									</div>
									<?php } ?>
									<div class="item-relate-content">
										<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
										<div class="entry-summary">
											<?php 												
												if ( preg_match('/<!--more(.*?)?-->/', $post->post_content, $matches) ) {
													echo wp_trim_words($post->post_content, 13, '');
												} else {
													the_content('...');
												}		
											?>
										</div>
										<div class="entry-meta clearfix">
										<?php echo ( $pr_location ) ? '<div class="meta-item col-md-6 col-sm-6 col-xs12"><p>' . esc_html__( 'Location', 'sw_core' ) . '</p> <span>'. esc_html( $pr_location ) .'</span></div>' : ''; ?>
										<?php echo ( $pr_year ) ? '<div class="meta-item col-md-6 col-sm-6 col-xs12"><p>' . esc_html__( 'Year', 'sw_core' ) . '</p> <span>'. esc_html( $pr_year ) .'</span></div>' : ''; ?>
										</div>
									</div>
								</div>
							<?php endwhile; wp_reset_postdata(); ?>
						</div>
						</div>
					</div>
					<?php } ?>
				</div>
			<?php endwhile; ?>
		</div>
	</div>	
</div>