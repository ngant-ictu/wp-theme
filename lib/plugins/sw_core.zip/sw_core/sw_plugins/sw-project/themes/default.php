<?php 
	$this->Portfolio_Script();
	if( !is_array( $category ) && count( $category ) == 0 ){
		return ;
	}
	$attributes = 'grid-item col-lg-'.$columns .' col-md-'.$columns1 .' col-sm-'.$columns2 .' col-xs-'.$columns3; 
	
	$args = array(
		'post_type' => 'project',
		'tax_query' => array(
			array(
				'taxonomy'	=> 'project_cat',
				'field' 	=> 'term_id',
				'terms'		=> $category
			)
		),
		'orderby'	=> $orderby,
		'order'	=> $order,
		'showposts' => $numberposts
	);
	$query = new WP_Query( $args );
	$max_page = $query -> max_num_pages;
	$pf_id = 'project' . time();
	if( $query->have_posts() ) :
?>
<div id="<?php echo esc_attr( $pf_id ); ?>" class="project-portfolio" data-layout="layout1" data-categories="<?php echo implode( ',', $category ); ?>" data-max_page="<?php echo esc_attr( $max_page ); ?>" data-number="<?php echo esc_attr( $numberposts ) ?>" data-length="<?php echo esc_attr( $length ) ?>" data-orderby="<?php echo esc_attr( $orderby ) ?>" data-order="<?php echo esc_attr( $order ) ?>" data-style="fitRows" data-attributes="<?php echo esc_attr( $attributes ) ?>">
	<!-- Tab  -->
	<div class="portfolio-tab">
		<button class="button-collapse collapsed" type="button" data-toggle="collapse" data-target="#<?php echo 'tab_'.$pf_id; ?>" aria-expanded="false"></button>
		<ul id="tab_<?php echo esc_attr( $pf_id ); ?>">
		<li class="selected" data-portfolio-filter="*"><?php esc_html_e( 'All', 'sw_core' ); ?></li>
		<?php
			foreach( $category as $cat_id ){
				$cat = get_term_by( 'term_id', $cat_id, 'project_cat' );
				echo '<li data-portfolio-filter=".'. $cat->term_id .'">' .esc_html( $cat -> name ). '</li>';
			}
		?>
		</ul>
	</div>
	<!-- Container -->
	<div class="portfolio-container">
		<ul id="container_<?php echo esc_attr( $pf_id ); ?>" class="portfolio-content row clearfix" >
		<?php
			while( $query -> have_posts() ) : $query -> the_post();
			global $post;			
			$pr_location 	 = get_post_meta( $post->ID, 'pr_location', true );
			$pr_year = get_post_meta( $post->ID, 'pr_year', true );
			$pterms	   	= get_the_terms( $post->ID, 'project_cat' );
			$term_str  = '';
			if( count($pterms) > 0 ){
				foreach( $pterms as $key => $term ){
					$term_str .= $term->term_id . ' ';
				}
			}	
			$img = '';
		?>
				<li class="grid-item <?php echo $attributes.' '.esc_attr( $term_str ); ?>">
					<div class="item-content">
						<?php 
							$feat_image_url = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
							if ( $feat_image_url ){ 
						?>
						<div class="item-img">
							<a href="<?php echo get_permalink($post->ID)?>" title="<?php the_title_attribute(); ?>">
							<?php 								
								$width  = 370;
								$height = 400;
								$image = sw_image_resize( $feat_image_url, $width, $height, true );
								echo '<img src="'. esc_url( $image['url'] ) .'" alt="'. esc_attr( $post->post_title ) .'">';
							?>
							</a>
						</div>
						<?php } ?>
						<div class="entry-content">
							<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
							<div class="description">
								<?php 										
									$content = wp_trim_words($post->post_content, $length, '');						
									echo $content;
								?>
							</div>
							<div class="entry-meta clearfix">
								<?php echo ( $pr_location ) ? '<div class="meta-item col-md-6 col-sm-6 col-xs12"><p>' . esc_html__( 'Location', 'sw_core' ) . '</p> <span>'. esc_html( $pr_location ) .'</span></div>' : ''; ?>
								<?php echo ( $pr_year ) ? '<div class="meta-item col-md-6 col-sm-6 col-xs12"><p>' . esc_html__( 'Year', 'sw_core' ) . '</p> <span>'. esc_html( $pr_year ) .'</span></div>' : ''; ?>
							</div>
						</div>
					</div>
				</li>
		<?php 
			endwhile;
			wp_reset_postdata();
		?>
		</ul>
	</div>
	<div class="pagination-ajax"><button class="btn-loadmore button-ajax" data-loadmore_style="1" data-title="<?php esc_html_e( "Loading more...", 'sw_core' ) ?>" data-loaded="<?php esc_html_e( "All Items Loaded", 'sw_core' ) ?>"></button></div>
</div>
<?php endif; ?>