<?php get_header(); ?>
<?php kontruk_breadcrumb_title(); ?>
<div class="container">
	<div class="row sidebar-row">	
		<div class="category-contents">
			<!-- No Result -->			
			<?php if( have_posts() ) : ?>
				<div class="service-content blog-content">
					<?php while( have_posts() ) : the_post();
					global $post; 
					?>
					<div id="post-<?php the_ID();?>" class="col-md-4 col-sm-4 col-xs-12 service theme-clearfix">
						<div class="entry clearfix">
							<?php if ( has_post_thumbnail() ){ ?>
								<div class="entry-thumb">					
									<a class="entry-hover" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
										<?php the_post_thumbnail('kontruk_blog-responsive1'); ?>			
									</a>			
								</div>
							<?php } ?>	
							<div class="entry-content">	
								<div class="content-top clearfix">
									<div class="entry-title">
										<h4><a href="<?php echo get_permalink($post->ID)?>"><?php echo $post->post_title; ?></a></h4>
									</div>
									<div class="readmore"><a href="<?php echo get_permalink($post->ID)?>"><?php esc_html_e('Explore the feature', 'sw_core'); ?></a></div>
								</div>
							</div>
						</div>
					</div>
				<?php endwhile; ?>
				<?php echo paginate_links( array(
					'prev_text'          => __('Previous Page'),
					'next_text'          => __('Next Page'),
					'type'               => 'list'
				) ); ?>
			</div>
			<div class="clearfix"></div>
		<?php endif; ?>
	</div>
</div>
</div>
<?php get_footer(); ?>