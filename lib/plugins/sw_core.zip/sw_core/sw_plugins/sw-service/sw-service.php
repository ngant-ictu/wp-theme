<?php
/**
 * Name: SW service Slider Widget
 * Description: A widget that serves as an slider for developing more advanced widgets.
 */
 
// Get gallery ID
function sw_get_service_gallery( $postid_service ){
	global $post;
	$gallery_service	  = get_post_meta( $postid_service, 'sv_gallery', true );
	$gallery_id_service = array();
	if( $gallery_service !== '' ){
		$gallery_id_service = explode( ',', $gallery_service );
	}
	
	$image_id_service 	 = get_post_thumbnail_id( $postid_service );
	array_unshift( $gallery_id_service, $image_id_service );
	$gallery_id_service = array_unique( $gallery_id_service );
	return $gallery_id_service;
}

if( !class_exists('sw_services') ) :
	add_action( 'widgets_init', 'sw_service_register' );
	function sw_service_register(){
		register_widget( 'sw_services' );
	}	 

	class sw_services extends WP_Widget {
	
	private $snumber = 1;
	function __construct() {

		/* Widget settings. */
		$widget_ops = array( 'classname' => 'sw_services', 'description' => __('Sw Service Widget', 'sw_core') );

		/* Widget control settings. */
		$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'sw_services' );

		/* Create the widget. */
		parent::__construct( 'sw_services', __('Sw Service Widget', 'sw_core'), $widget_ops, $control_ops );

		/* Register Taxonomy */
		add_action( 'init', array( $this, 'service_register' ), 3 );	
		add_action( 'admin_init', array( $this, 'service_init' ) );
		add_action( 'save_post', array( $this, 'service_save_meta' ), 10, 1 );
	
		/* Create Shortcode */
		add_shortcode( 'service', array( $this, 'SV_Shortcode' ) );
		add_filter( 'template_include', array( $this, 'sw_service_template_load' ) );

		/* Create Vc_map */
		if (class_exists('Vc_Manager')) {
			add_action( 'vc_before_init', array( $this, 'SV_integrateWithVC' ), 20 );
		}
		add_action( 'admin_enqueue_scripts', array( $this, 'sw_service_admin_settings_script' ) );
		add_action( 'wp_footer', array( $this, 'sw_footer_customs' ), 200 );
	}
	
	/*
	** Generate ID
	*/
	public function generateID() {
		return 'sw_service_' . (int) $this->snumber++;
	}
	
	function sw_footer_customs(){
		if( is_singular( 'service' ) ) :
			global $post;
			if( count( sw_get_service_gallery( $post->ID ) ) ) :
				echo '<script>jQuery("a.gallery-single-item").fancybox();</script>';
			endif;
		endif;
	}
	
	function sw_service_admin_settings_script(){
		$current_screen =  isset( get_current_screen()->id ) ? get_current_screen()->id : '';	
		if( $current_screen === 'service_page_service-settings' || $current_screen === 'service' ){
			$args = array(
				'service_upload_img' 		=> esc_html__( 'Upload/Add image', 'sw_core' ),
				'service_upload_rmimg' 		=> esc_html__( 'Remove image', 'sw_core' ),
				'service_rmbutton' 			=> esc_html__( 'Remove', 'sw_core' ),
				'setting_media_title' 		=> esc_html__( "Choose an image", 'sw_core' ),
				'setting_text_message' 		=> esc_html__( "Sale price must less than main price", 'sw_core' ),
				'setting_media_button_text' => esc_html__( "Use image", 'sw_core' ),
				'setting_img_placehold' 	=> sw_placeholder_img_src()
			);	
			wp_enqueue_style( '_service_settings_style', SWURL . '/css/admin/style2.css', array(), null );
			wp_enqueue_media();
			wp_register_script( '_service_settings', SWURL . '/js/admin/admin2.min.js', array(), null, true );
			wp_localize_script( '_service_settings', 'setting_val', $args );
			wp_enqueue_script( '_service_settings' );
		}
	}
	
	function service_register() { 
		$labels = array(
			'name' => __('Service', 'sw_core'),
			'singular_name' => __('Service Item', 'sw_core'),
			'add_new' => __('Add New', 'sw_core'),
			'add_new_item' => __('Add New Item', 'sw_core'),
			'edit_item' => __('Edit Item', 'sw_core'),
			'new_item' => __('New Item', 'sw_core'),
			'view_item' => __('View Item', 'sw_core'),
			'search_items' => __('Search', 'sw_core'),
			'not_found' =>  __('Nothing found', 'sw_core'),
			'not_found_in_trash' => __('Nothing found in Trash'),
			'parent_item_colon' => ''
		);

		$args = array(
			'labels' => $labels,
			'public' => true,
			'has_archive' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			'menu_icon' => 'dashicons-media-spreadsheet',
			'rewrite' =>  true,
			'capability_type' => 'post',
			'hierarchical' => true,
			'menu_position' => 4,
			'supports' => array( 'title', 'thumbnail', 'editor' )
		  );


		register_post_type( 'service' , $args );
		register_taxonomy( 'service_cat', array( 'service' ), array( 'hierarchical' => true, 'label' => esc_html__( 'Categories Service', 'sw_core' ), 'singular_label' => esc_html__( 'Categories Service', 'sw_core' ), 'rewrite' => array( 'slug' => esc_html__( 'service_cat', 'sw_core' ) ) ) );
		register_taxonomy( 'service_tag', 'service', array(
			'hierarchical' => false, 
			'label' => esc_html__( 'Tags', 'sw_core' ), 
			'singular_name' => esc_html__( 'Tag', 'sw_core' ), 
			'rewrite' => array( 'slug' => esc_html__( 'service_tag', 'sw_core' ) ), 
			'query_var' => true
			)
		);
	}
	
	function service_init(){	
		add_meta_box( 'sw_service_gallery_meta', esc_html__( 'Service image icon', 'sw_core' ), array( $this, 'sw_service_gallery_meta' ), 'service', 'side', 'low' );
	}
	
	/* Metabox galleries */
	function sw_service_gallery_meta(){
		global $post;
		wp_nonce_field( 'sw_service_save_meta', 'sw_service_gallery_nonce' );
		$gallery_service	 = get_post_meta( $post->ID, 'sv_gallery', true );
	?>
		<div class="service-gallery">
			<div class="gallery-append">
				<?php if( $gallery_service ) : ?>
				<ul>
				<?php 
					$images_service = explode( ',', $gallery_service );
					foreach( $images_service as $key => $img_service ){
				?>
					<li><img src="<?php echo wp_get_attachment_thumb_url($img_service) ?>" alt="" id="<?php echo esc_attr( $img_service ); ?>"/><span class="gallery-remove" data-id="<?php echo esc_attr( $img_service ); ?>"></span></li>
				<?php } ?>
				</ul>
				<?php endif; ?>
			</div>
			<a href="javascript:void(0)" data-toggle="service_gallery"><?php echo esc_html__( 'Upload image icon', 'sw_core' ); ?></a>
			<input type="hidden" name="sv_gallery" value="<?php echo esc_attr( $gallery_service ); ?>"/>		
		</div>
	<?php 
	}
	
	function service_save_meta( $post_id ){
		
		$list_meta_service = array( 'sv_gallery' );
		foreach( $list_meta_service as $meta_service ){
			if( isset( $_POST[$meta_service] ) ){
				$my_data_service = $_POST[$meta_service];
				update_post_meta( $post_id, $meta_service, $my_data_service );
			}
		}
	}
		
	
	// Get template content
	function sw_service_template_load( $template ){
		// Food template check
		if( is_post_type_archive( 'service' ) || is_tax( 'service_cat' ) || is_tax( 'service_tag' ) ){
			$template = sw_core_override_check( 'sw-service/loop', 'archive-service' );
		}	
		if( is_singular( 'service' ) ){
			$template = sw_core_override_check( 'sw-service/single-service', 'single-service' );
		}

		return $template;
	}

	/**
	* VC Integrate
	**/
	function SV_integrateWithVC(){
		$terms = get_terms( 'service_cat', array( 'parent' => '', 'hide_empty' => false ) );
		$term = array( __( 'All Categories', 'sw_core' ) => '' );
		if( count( $terms )  > 0 ){
			foreach( $terms as $cat ){
				$term[$cat->name] = $cat -> term_id;
			}
		}
		vc_map( array(
			'name' =>  __( 'Sw service Slider', 'sw_core' ),
			'base' => 'service',
			"icon" => "icon-wpb-ytc",
			'category' => __( 'SW Core', 'sw_core' ),
			'class' => 'wpb_vc_wp_widget',
			'weight' => - 50,
			'description' => '',
			'params' => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Title", 'sw_core' ),
					"param_name" => "title",
					"admin_label" => true,
					"value" => '',
					"description" => __( "Title", 'sw_core' )
				 ),
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Description", 'sw_core' ),
					"param_name" => "description",
					"admin_label" => true,
					"value" => '',
					"description" => __( "Description", 'sw_core' )
				),
				 array(
					"type" => "multiselect",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Category", 'sw_core' ),
					"param_name" => "category",
					"admin_label" => true,
					"value" => $term,
					"description" => __( "Select Category", 'sw_core' )
				),
				
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number Of Post", 'sw_core' ),
					"param_name" => "numberposts",
					"admin_label" => true,
					"value" => 5,
					"description" => __( "Number Of Post", 'sw_core' )
				 ),				 
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number row per column", 'sw_core' ),
					"param_name" => "item_row",
					"admin_label" => true,
					"value" =>array(1,2,3),
					"description" => __( "Number row per column", 'sw_core' )
				 ),				 
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Order By", 'sw_core' ),
					"param_name" => "orderby",
					"admin_label" => true,
					"value" => array('Name' => 'name', 'Author' => 'author', 'Date' => 'date', 'Title' => 'title', 'Modified' => 'modified', 'Parent' => 'parent', 'ID' => 'ID', 'Random' =>'rand', 'Comment Count' => 'comment_count'),
					"description" => __( "Order By", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Order", 'sw_core' ),
					"param_name" => "order",
					"admin_label" => true,
					"value" => array('Descending' => 'DESC', 'Ascending' => 'ASC'),
					"description" => __( "Order", 'sw_core' )
				 ),
				array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns >1200px: ", 'sw_core' ),
					"param_name" => "columns",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns >1200px:", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns on 992px to 1199px:", 'sw_core' ),
					"param_name" => "columns1",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns on 992px to 1199px:", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns on 768px to 991px:", 'sw_core' ),
					"param_name" => "columns2",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns on 768px to 991px:", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns on 480px to 767px:", 'sw_core' ),
					"param_name" => "columns3",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns on 480px to 767px:", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns in 480px or less than:", 'sw_core' ),
					"param_name" => "columns4",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns in 480px or less than:", 'sw_core' )
				 ),
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Speed", 'sw_core' ),
					"param_name" => "speed",
					"admin_label" => true,
					"value" => 1000,
					"description" => __( "Speed Of Slide", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Auto Play", 'sw_core' ),
					"param_name" => "autoplay",
					"admin_label" => true,
					"value" => array( 'False' => 'false', 'True' => 'true' ),
					"description" => __( "Auto Play", 'sw_core' )
				 ),
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Interval", 'sw_core' ),
					"param_name" => "interval",
					"admin_label" => true,
					"value" => 5000,
					"description" => __( "Interval", 'sw_core' )
				 ),
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Total Items Slided", 'sw_core' ),
					"param_name" => "scroll",
					"admin_label" => true,
					"value" => 1,
					"description" => __( "Total Items Slided", 'sw_core' )
				 ),
			 	array(
					'type' => 'dropdown',
					'holder' => 'div',
					'heading' => __( 'Layout', 'sw_core' ),
					'param_name' => 'layout',
					"admin_label" => true,
					'value' => array(
						__( 'Layout Default','sw_core' ) => 'default',
						__( 'Layout Listing','sw_core' ) => 'layout1',			
					),
					'description' => sprintf( __( 'Select Layout', 'sw_core' ) )
				),	
				array(
					'type' => 'textfield',
					'heading' => __( 'Extra class name', 'sw_core' ),
					'param_name' => 'el_class',
					"admin_label" => true,
					'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_core' )
				),
			)
		) );
	}
	
	/**
	* Add Shortcode
	**/
	function SV_Shortcode( $atts,$content = null ){
		extract(shortcode_atts(array(
			'el_class'=> '',
			'title'=> '',
			'description' => '',
			'category'=> '',
			'orderby' => 'name',
			'order' => 'DESC',
			'numberposts' => 5,
			'item_row' => 1,
			'columns' => 4,
			'columns1' => 4,
			'columns2' => 3,
			'columns3' => 2,
			'columns4' => 1,
			'speed' => 1000,
			'autoplay' => 'false',
			'interval' => 5000,
			'layout'  => 'default',
			'scroll' => 1
		 ),$atts));
		ob_start();		
		if( $layout == 'default' ){
			include( sw_core_override_check( 'sw-service/themes/', 'default' ) );	
		}else{
			include( sw_core_override_check( 'sw-service/themes/', 'layout1' ) );	
		}
		$content = ob_get_clean();
		
		return $content;
	}
		
	/**
	 * Display the widget on the screen.
	 */
	public function widget( $args, $instance ) {
		wp_reset_postdata();
		extract($args);
		$title = apply_filters( 'widget_title', empty( $instance['title1'] ) ? '' : $instance['title1'], $instance, $this->id_base );
		$description1 = apply_filters( 'widget_description', empty( $instance['description1'] ) ? '' : $instance['description1'], $instance, $this->id_base );
		echo $before_widget;
		if ( !empty( $title ) && !empty( $description1 ) ) { echo $before_title . $title . $after_title . '<h5 class="category_description clearfix">' . $description1 . '</h5>'; }
		else if (!empty( $title ) && $description1==NULL ){ echo $before_title . $title . $after_title; }
		
		if (!isset($instance['category'])){
			$instance['category'] = 0;
		}
		extract($instance);

		if ( !array_key_exists('widget_template', $instance) ){
			$instance['widget_template'] = 'default';
		}
		
		if ( $tpl = $this->getTemplatePath( $instance['widget_template'] ) ){ 
			$widget_id = $args['widget_id'];		
			include $tpl;
		}
				
		/* After widget (defined by themes). */
		echo $after_widget;
	}    

	protected function getTemplatePath($tpl='default', $type=''){
		$file = '/'.$tpl.$type.'.php';
		$dir =realpath(dirname(__FILE__)).'/themes';
		
		if ( file_exists( $dir.$file ) ){
			return $dir.$file;
		}
		
		return $tpl=='default' ? false : $this->getTemplatePath('default', $type);
	}
	
	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		// strip tag on text field
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['title2'] = strip_tags( $new_instance['title2'] );
		$instance['description'] = strip_tags( $new_instance['description'] );
		// int or array
		if ( array_key_exists('category', $new_instance) ){
			if ( is_array($new_instance['category']) ){
				$instance['category'] = array_map( 'intval', $new_instance['category'] );
			}
		}
		
		if ( array_key_exists('orderby', $new_instance) ){
			$instance['orderby'] = strip_tags( $new_instance['orderby'] );
		}

		if ( array_key_exists('order', $new_instance) ){
			$instance['order'] = strip_tags( $new_instance['order'] );
		}

		if ( array_key_exists('numberposts', $new_instance) ){
			$instance['numberposts'] = intval( $new_instance['numberposts'] );
		}
		if ( array_key_exists('item_row', $new_instance) ){
			$instance['item_row'] = intval( $new_instance['item_row'] );
		}
		if ( array_key_exists('length', $new_instance) ){
			$instance['length'] = intval( $new_instance['length'] );
		}
		
		if ( array_key_exists('columns', $new_instance) ){
			$instance['columns'] = intval( $new_instance['columns'] );
		}
		if ( array_key_exists('columns1', $new_instance) ){
			$instance['columns1'] = intval( $new_instance['columns1'] );
		}
		if ( array_key_exists('columns2', $new_instance) ){
			$instance['columns2'] = intval( $new_instance['columns2'] );
		}
		if ( array_key_exists('columns3', $new_instance) ){
			$instance['columns3'] = intval( $new_instance['columns3'] );
		}
		if ( array_key_exists('columns4', $new_instance) ){
			$instance['columns4'] = intval( $new_instance['columns4'] );
		}		
		if ( array_key_exists('interval', $new_instance) ){
			$instance['interval'] = intval( $new_instance['interval'] );
		}
		if ( array_key_exists('speed', $new_instance) ){
			$instance['speed'] = intval( $new_instance['speed'] );
		}
		if ( array_key_exists('start', $new_instance) ){
			$instance['start'] = intval( $new_instance['start'] );
		}
		if ( array_key_exists('scroll', $new_instance) ){
			$instance['scroll'] = intval( $new_instance['scroll'] );
		}	
		if ( array_key_exists('autoplay', $new_instance) ){
			$instance['autoplay'] = strip_tags( $new_instance['autoplay'] );
		}
		$instance['widget_template'] = strip_tags( $new_instance['widget_template'] );
				
				
		return $instance;
	}

	function category_select( $field_name, $opts = array(), $field_value = null ){
		$default_options = array(
				'multiple' => true,
				'disabled' => false,
				'size' => 5,
				'class' => 'widefat',
				'required' => false,
				'autofocus' => false,
				'form' => false,
		);
		$opts = wp_parse_args($opts, $default_options);
	
		if ( (is_string($opts['multiple']) && strtolower($opts['multiple'])=='multiple') || (is_bool($opts['multiple']) && $opts['multiple']) ){
			$opts['multiple'] = 'multiple';
			if ( !is_numeric($opts['size']) ){
				if ( intval($opts['size']) ){
					$opts['size'] = intval($opts['size']);
				} else {
					$opts['size'] = 5;
				}
			}
		} else {
			// is not multiple
			unset($opts['multiple']);
			unset($opts['size']);
			if (is_array($field_value)){
				$field_value = array_shift($field_value);
			}
			if (array_key_exists('allow_select_all', $opts) && $opts['allow_select_all']){
				unset($opts['allow_select_all']);
				$allow_select_all = '<option value="0">All Categories</option>';
			}
		}
	
		if ( (is_string($opts['disabled']) && strtolower($opts['disabled'])=='disabled') || is_bool($opts['disabled']) && $opts['disabled'] ){
			$opts['disabled'] = 'disabled';
		} else {
			unset($opts['disabled']);
		}
	
		if ( (is_string($opts['required']) && strtolower($opts['required'])=='required') || (is_bool($opts['required']) && $opts['required']) ){
			$opts['required'] = 'required';
		} else {
			unset($opts['required']);
		}
	
		if ( !is_string($opts['form']) ) unset($opts['form']);
	
		if ( !isset($opts['autofocus']) || !$opts['autofocus'] ) unset($opts['autofocus']);
	
		$opts['id'] = $this->get_field_id($field_name);
	
		$opts['name'] = $this->get_field_name($field_name);
		if ( isset($opts['multiple']) ){
			$opts['name'] .= '[]';
		}
		$select_attributes = '';
		foreach ( $opts as $an => $av){
			$select_attributes .= "{$an}=\"{$av}\" ";
		}
		
		$categories = get_terms('service_cat');
		//print '<pre>'; var_dump($categories);
		// if (!$templates) return '';
		$all_category_ids = array();
		foreach ($categories as $cat) $all_category_ids[] = $cat->term_id;
		
		$is_valid_field_value = is_numeric($field_value) && in_array($field_value, $all_category_ids);
		if (!$is_valid_field_value && is_array($field_value)){
			$intersect_values = array_intersect($field_value, $all_category_ids);
			$is_valid_field_value = count($intersect_values) > 0;
		}
		if (!$is_valid_field_value){
			$field_value = '0';
		}
	
		$select_html = '<select ' . $select_attributes . '>';
		if (isset($allow_select_all)) $select_html .= $allow_select_all;
		foreach ($categories as $cat){
			$select_html .= '<option value="' . $cat->term_id . '"';
			if ($cat->term_id == $field_value || (is_array($field_value)&&in_array($cat->term_id, $field_value))){ $select_html .= ' selected="selected"';}
			$select_html .=  '>'.$cat->name.'</option>';
		}
		$select_html .= '</select>';
		return $select_html;
	}
	

	/**
	 * Displays the widget settings controls on the widget panel.
	 * Make use of the get_field_id() and get_field_name() function
	 * when creating your form elements. This handles the confusing stuff.
	 */
	public function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array();
		$instance = wp_parse_args( (array) $instance, $defaults ); 		
						 
		$title = isset( $instance['title'] )    ? 	strip_tags($instance['title']) : '';
		$title2 = isset( $instance['title2'] )    ? 	strip_tags($instance['title2']) : '';
		$description = isset( $instance['description'] )    ? 	strip_tags($instance['description']) : '';
		$categoryid = isset( $instance['category'] )    	? $instance['category'] : 0;
		$orderby    = isset( $instance['orderby'] )     	? strip_tags($instance['orderby']) : 'ID';
		$order      = isset( $instance['order'] )       	? strip_tags($instance['order']) : 'ASC';
		$number     = isset( $instance['numberposts'] ) 	? intval($instance['numberposts']) : 5;
		$item_row   = isset( $instance['item_row'] )    	? intval($instance['item_row']) : 1;
		$length     = isset( $instance['length'] )      	? intval($instance['length']) : 25;
		$columns    = isset( $instance['columns'] )      	? intval($instance['columns']) : '';
		$columns1   = isset( $instance['columns1'] )      	? intval($instance['columns1']) : '';
		$columns2   = isset( $instance['columns2'] )      	? intval($instance['columns2']) : '';
		$columns3   = isset( $instance['columns3'] )      	? intval($instance['columns3']) : '';
		$columns4   = isset( $instance['columns4'] )      	? intval($instance['columns4']) : '';
		$autoplay   = isset( $instance['autoplay'] )      	? strip_tags($instance['autoplay']) : 'true';
		$interval   = isset( $instance['interval'] )      	? intval($instance['interval']) : 5000;
		$speed     	= isset( $instance['speed'] )      		? intval($instance['speed']) : 1000;
		$scroll     = isset( $instance['scroll'] )      	? intval($instance['scroll']) : 1;
		$widget_template   = isset( $instance['widget_template'] ) ? strip_tags($instance['widget_template']) : 'default';

								 
		?>		
			</p> 
				<div style="background: Blue; color: white; font-weight: bold; text-align:center; padding: 3px"> * Data Config * </div>
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>"
					type="text"	value="<?php echo esc_attr($title); ?>" />
			</p>

			<p>
				<label for="<?php echo $this->get_field_id('title2'); ?>"><?php _e('Title 2', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('title2'); ?>" name="<?php echo $this->get_field_name('title2'); ?>"
					type="text"	value="<?php echo esc_attr($title2); ?>" />
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('description'); ?>"><?php _e('Description', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>"
					type="text"	value="<?php echo esc_attr($description); ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('category'); ?>"><?php _e('Category ID', 'sw_core')?></label>
				<br />
				<?php echo $this->category_select('category', array('allow_select_all' => true), $categoryid); ?>
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('orderby'); ?>"><?php _e('Orderby', 'sw_core')?></label>
				<br />
				<?php $allowed_keys = array('name' => 'Name', 'author' => 'Author', 'date' => 'Date', 'title' => 'Title', 'modified' => 'Modified', 'parent' => 'Parent', 'ID' => 'ID', 'rand' =>'Rand', 'comment_count' => 'Comment Count'); ?>
				<select class="widefat"
					id="<?php echo $this->get_field_id('orderby'); ?>"
					name="<?php echo $this->get_field_name('orderby'); ?>">
					<?php
					$option ='';
					foreach ($allowed_keys as $value => $key) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $orderby){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p>

			<p>
				<label for="<?php echo $this->get_field_id('order'); ?>"><?php _e('Order', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('order'); ?>" name="<?php echo $this->get_field_name('order'); ?>">
					<option value="DESC" <?php if ($order=='DESC'){?> selected="selected"
					<?php } ?>>
						<?php _e('Descending', 'sw_core')?>
					</option>
					<option value="ASC" <?php if ($order=='ASC'){?> selected="selected"	<?php } ?>>
						<?php _e('Ascending', 'sw_core')?>
					</option>
				</select>
			</p>

			<p>
				<label for="<?php echo $this->get_field_id('numberposts'); ?>"><?php _e('Number of Posts', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('numberposts'); ?>" name="<?php echo $this->get_field_name('numberposts'); ?>"
					type="text"	value="<?php echo esc_attr($number); ?>" />
			</p>

			<?php $row_number = array( '1' => 1, '2' => 2, '3' => 3 ); ?>
			<p>
				<label for="<?php echo $this->get_field_id('item_row'); ?>"><?php _e('Number row per column:  ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('item_row'); ?>"
					name="<?php echo $this->get_field_name('item_row'); ?>">
					<?php
					$option ='';
					foreach ($row_number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $item_row){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 

			<p>
				<label for="<?php echo $this->get_field_id('length'); ?>"><?php _e('Excerpt length (in words): ', 'sw_core')?></label>
				<br />
				<input class="widefat"
					id="<?php echo $this->get_field_id('length'); ?>" name="<?php echo $this->get_field_name('length'); ?>" type="text" 
					value="<?php echo esc_attr($length); ?>" />
			</p>  
			<?php $number = array('1' => 1, '2' => 2, '3' => 3, '4' => 4, '5' => 5, '6' => 6); ?>
			<p>
				<label for="<?php echo $this->get_field_id('columns'); ?>"><?php _e('Number of Columns >1200px: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns'); ?>"
					name="<?php echo $this->get_field_name('columns'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('columns1'); ?>"><?php _e('Number of Columns on 992px to 1199px: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns1'); ?>"
					name="<?php echo $this->get_field_name('columns1'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns1){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('columns2'); ?>"><?php _e('Number of Columns on 768px to 991px: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns2'); ?>"
					name="<?php echo $this->get_field_name('columns2'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns2){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('columns3'); ?>"><?php _e('Number of Columns on 480px to 767px: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns3'); ?>"
					name="<?php echo $this->get_field_name('columns3'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns3){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('columns4'); ?>"><?php _e('Number of Columns in 480px or less than: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns4'); ?>"
					name="<?php echo $this->get_field_name('columns4'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns4){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('autoplay'); ?>"><?php _e('Auto Play', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('autoplay'); ?>" name="<?php echo $this->get_field_name('autoplay'); ?>">
					<option value="false" <?php if ($autoplay=='false'){?> selected="selected" <?php } ?>>
						<?php _e('False', 'sw_core')?>
					</option>
					<option value="true" <?php if ($autoplay=='true'){?> selected="selected" <?php } ?>>
						<?php _e('True', 'sw_core')?>
					</option>
				</select>
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('interval'); ?>"><?php _e('Interval', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('interval'); ?>" name="<?php echo $this->get_field_name('interval'); ?>"
					type="text"	value="<?php echo esc_attr($interval); ?>" />
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('speed'); ?>"><?php _e('Speed', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('speed'); ?>" name="<?php echo $this->get_field_name('speed'); ?>"
					type="text"	value="<?php echo esc_attr($speed); ?>" />
			</p>			
			
			<p>
				<label for="<?php echo $this->get_field_id('scroll'); ?>"><?php _e('Total Items Slided', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('scroll'); ?>" name="<?php echo $this->get_field_name('scroll'); ?>"
					type="text"	value="<?php echo esc_attr($scroll); ?>" />
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('widget_template'); ?>"><?php _e("Template", 'sw_core')?></label>
				<br/>
				
				<select class="widefat" id="<?php echo $this->get_field_id('widget_template'); ?>"	name="<?php echo $this->get_field_name('widget_template'); ?>">
					<option value="default" <?php if ($widget_template=='default'){?> selected="selected"
					<?php } ?>>
						<?php _e('Default', 'sw_core')?>
					</option>
					<option value="layout1" <?php if ($widget_template=='layout1'){?> selected="selected"
					<?php } ?>>
						<?php _e('Layout Style 1', 'sw_core')?>
					</option>
					<option value="layout2" <?php if ($widget_template=='layout2'){?> selected="selected"
					<?php } ?>>
						<?php _e('Layout Style 2', 'sw_core')?>
					</option>
					<option value="layout3" <?php if ($widget_template=='layout3'){?> selected="selected"
					<?php } ?>>
						<?php _e('Layout Style 3', 'sw_core')?>
					</option>
					<option value="layout4" <?php if ($widget_template=='layout4'){?> selected="selected"
					<?php } ?>>
						<?php _e('Layout Style 4', 'sw_core')?>
					</option>	
				</select>
			</p>           
		<?php
		}	
	}
endif;
?>