<?php get_header(); ?>
<?php kontruk_breadcrumb_title(); ?>
<div class="container">
	<div class="row sidebar-row">
		<div class="single main">
			<?php while (have_posts()) : the_post(); global $post; ?>
				<div <?php post_class(); ?>>
					<div class="entry-wrap clearfix">
						<div class="sidebar entry-sidebar col-md-4 col-sm-4 col-xs-12">
							<?php if( is_active_sidebar( 'left-service' ) ): ?>
								<?php dynamic_sidebar( 'left-service' ); ?>
							<?php endif; ?>
						</div>
						<div class="entry-content col-md-8 col-sm-8 col-xs-12">
							<?php the_content(); ?>
						</div>
					</div>
				</div>
			<?php endwhile; ?>
		</div>
	</div>
</div>
<?php get_footer(); ?>