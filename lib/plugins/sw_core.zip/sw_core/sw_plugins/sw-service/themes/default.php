<?php 
	$widget_id = $this->generateID();
	$default = array(
		'post_type' => 'service',
		'orderby' => $orderby,
		'order' => $order,
		'post_status' => 'publish',
		'showposts' => $numberposts
	);
	
	if( is_array( $category ) && count( $category ) ){
		$default['tax_query'] = array(
			array(
				'taxonomy'  => 'service_cat',
				'field'     => 'term_id',
				'terms'     => $category )
		);	
	}
	$list = new WP_Query( $default );
	if ( $list->have_posts() ){
	$i = 0;
?>
	<div id="<?php echo esc_attr( $widget_id ) ?>" class="service-slider responsive-slider loading clearfix"  data-lg="<?php echo esc_attr( $columns ); ?>" data-md="<?php echo esc_attr( $columns1 ); ?>" data-sm="<?php echo esc_attr( $columns2 ); ?>" data-xs="<?php echo esc_attr( $columns3 ); ?>" data-mobile="<?php echo esc_attr( $columns4 ); ?>" data-speed="<?php echo esc_attr( $speed ); ?>" data-scroll="<?php echo esc_attr( $scroll ); ?>" data-interval="<?php echo esc_attr( $interval ); ?>" data-autoplay="<?php echo esc_attr( $autoplay ); ?>">
		<div class="resp-slider-container">
			<?php if( $title != '' ){?>
			<div class="title-style1 clearfix">	
				<div class="block-title pull-left">
					<p><?php echo $description; ?></p>
					<h3><?php echo $title; ?></h3>
				</div>
				<div class="more pull-right"><a href="<?php echo get_post_type_archive_link( 'service' ); ?>"><?php esc_html_e( 'explore all', 'sw_core' ) ?></a></div>
			</div>
			<?php } ?>
			<div class="slider responsive">	
			<?php 
				$count_items 	= 0;
				$numb 			= ( $list->found_posts > 0 ) ? $list->found_posts : count( $list->posts );
				$count_items 	= ( $numberposts >= $numb ) ? $numb : $numberposts;
				$i 				= 0;
				while($list->have_posts()): $list->the_post();
				global $post;
				if( $i % $item_row == 0 ){
			?>
			<div class="item item-service">
			<?php } ?>
				<div class="item-inner">
					<div class="item-img">
						<a class="tops" href="<?php echo get_permalink($post->ID)?>" >
							<?php 
						if ( has_post_thumbnail( $post->ID ) ){
							
								echo get_the_post_thumbnail( $post->ID, 'kontruk_blog-responsive1' ) ? get_the_post_thumbnail( $post->ID, 'kontruk_blog-responsive1' ): '<img src="'.get_template_directory_uri().'/assets/img/placeholder/'.'large'.'.png" alt="No thumb">';		
						}else{
							echo '<img src="'.get_template_directory_uri().'/assets/img/placeholder/'.'large'.'.png" alt="No thumb">';
						}
						?></a>
						<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
						<div class="readmore"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php esc_html_e( 'Explore the feature', 'sw_core' ) ?></a></div>
						<?php if( count( sw_get_service_gallery( $post->ID ) ) ) : ?>
							<?php
								global $post;
								$gallery_service = get_post_meta( $post->ID, 'sv_gallery', true );
							?>
							<div class="item-gallery">
								<?php echo wp_get_attachment_image( $gallery_service, 'full', false, array() ); ?>
							</div>
						<?php endif; ?>	
					</div>
				</div>
			<?php if( ( $i+1 ) % $item_row == 0 || ( $i+1 ) == $count_items ){?> </div><?php } ?>
			<?php $i++; endwhile; wp_reset_postdata();?>
			</div>
		</div>
	</div>
<?php	
}else{
	echo '<div class="alert alert-warning alert-dismissible" role="alert">
		<a class="close" data-dismiss="alert">&times;</a>
		<p>'. esc_html__( 'There is not product in this category', 'sw_core' ) .'</p>
	</div>';
}