<?php 
	$widget_id = $this->generateID();
	$default = array(
		'post_type' => 'service',
		'orderby' => $orderby,
		'order' => $order,
		'post_status' => 'publish',
		'showposts' => $numberposts
	);
	
	if( is_array( $category ) && count( $category ) ){
		$default['tax_query'] = array(
			array(
				'taxonomy'  => 'service_cat',
				'field'     => 'term_id',
				'terms'     => $category )
		);	
	}
	$list = new WP_Query( $default );
	if ( $list->have_posts() ){
	$i = 0;
?>
	<div id="<?php echo esc_attr( $widget_id ) ?>" class="service-slider3 responsive-slider loading clearfix"  data-lg="<?php echo esc_attr( $columns ); ?>" data-md="<?php echo esc_attr( $columns1 ); ?>" data-sm="<?php echo esc_attr( $columns2 ); ?>" data-xs="<?php echo esc_attr( $columns3 ); ?>" data-mobile="<?php echo esc_attr( $columns4 ); ?>" data-speed="<?php echo esc_attr( $speed ); ?>" data-scroll="<?php echo esc_attr( $scroll ); ?>" data-interval="<?php echo esc_attr( $interval ); ?>" data-autoplay="<?php echo esc_attr( $autoplay ); ?>" data-dots="true">
		<?php if( $title != '' ){?>
			<div class="block-title clearfix">
				<h3><?php echo $title; ?></h3>
				<h4><?php echo $title2; ?></h4>
			</div>			
		<?php } ?>
		<div class="resp-slider-container">
			<div class="slider responsive">	
			<?php 
				$count_items 	= 0;
				$numb 			= ( $list->found_posts > 0 ) ? $list->found_posts : count( $list->posts );
				$count_items 	= ( $numberposts >= $numb ) ? $numb : $numberposts;
				$i 				= 0;
				while($list->have_posts()): $list->the_post();
				global $post;
				if( $i % $item_row == 0 ){
			?>
			<div class="item item-service">
			<?php } ?>
				<?php 
				$feat_image_url = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
					if ( $feat_image_url ){ 
				?>
				<div class="item-img">
					<a href="<?php echo get_permalink($post->ID)?>" title="<?php the_title_attribute(); ?>">
					<?php 								
						$width  = 410;
						$height = 550;
						$image = sw_image_resize( $feat_image_url, $width, $height, true );
						echo '<img src="'. esc_url( $image['url'] ) .'" alt="'. esc_attr( $post->post_title ) .'">';
					?>
					</a>
					<div class="readmore"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php esc_html_e( 'Explore +', 'sw_core' ) ?></a></div>
				</div>
				<?php } ?>
				<div class="item-content">
					<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
					<div class="description">
						<?php 										
							$content = wp_trim_words($post->post_content, 12, '');						
							echo $content;
						?>
					</div>
				</div>				
			<?php if( ( $i+1 ) % $item_row == 0 || ( $i+1 ) == $count_items ){?> </div><?php } ?>
			<?php $i++; endwhile; wp_reset_postdata();?>
			</div>
		</div>
	</div>
<?php	
}else{
	echo '<div class="alert alert-warning alert-dismissible" role="alert">
		<a class="close" data-dismiss="alert">&times;</a>
		<p>'. esc_html__( 'There is not product in this category', 'sw_core' ) .'</p>
	</div>';
}