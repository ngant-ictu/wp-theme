<?php get_header(); ?>
<div class="container">
	<div class="sidebar-row">
		<div class="single main">
			<?php while (have_posts()) : the_post(); ?>
				<?php 
					global $post; 
					$ap_bedrooms 	 = get_post_meta( $post->ID, 'ap_bedrooms', true );
					$ap_bathrooms = get_post_meta( $post->ID, 'ap_bathrooms', true );
					$ap_size = get_post_meta( $post->ID, 'ap_size', true );
					$ap_garages = get_post_meta( $post->ID, 'ap_garages', true );
					$ap_price = get_post_meta( $post->ID, 'ap_price', true );
				?>
				<div <?php post_class(); ?>>
					<!-- Entry Gallery -->
					<div class="entry-top clearfix">						
						<h2 class="entry-single-title"><?php the_title(); ?></h2>
						<div class="entry-content-single">
							<?php the_content(); ?>
						</div>
					</div>
					<?php if( count( sw_get_apartment_gallery( $post->ID ) ) ) : ?>
						<div id="<?php echo esc_attr( 'single_gallery' . $post->ID ); ?>" class="responsive-slider gallery-apartment loading" data-lg="1" data-md="1" data-sm="1" data-xs="1" data-mobile="1" data-speed="1000" data-scroll="1" data-interval="4000"  data-autoplay="false">
							<div class="slider responsive">	
							<?php 
								$galleries = sw_get_apartment_gallery( $post->ID );
								foreach( $galleries as $gallery ) {
								$image = wp_get_attachment_image_src( $gallery, 'full' );
							?>
								<div class="item-gallery">
									<a class="gallery-single-item" rel="group-gallery" href="<?php echo esc_url( $image[0] ); ?>"><?php echo wp_get_attachment_image( $gallery, 'full', false, array() ); ?></a>
								</div>
							<?php } ?>
							</div>
						</div>
					<?php endif; ?>
					<div class="clear"></div>
					<!-- Entry Top -->
					<div class="entry-bottom clearfix">	
						<div class="entry-meta">
							<?php echo ( $ap_bedrooms ) ? '<div class="meta-item"><h3>' . esc_html__( 'Bedrooms', 'sw_core' ) . '</h3> <span>'. esc_html( $ap_bedrooms ) . esc_html__( ' Bedrooms', 'sw_core' ) .'</span></div>' : ''; ?>
							<?php echo ( $ap_bathrooms ) ? '<div class="meta-item"><h3>' . esc_html__( 'Bathrooms', 'sw_core' ) . '</h3> <span>'. esc_html( $ap_bathrooms ) . esc_html__( ' Bathrooms', 'sw_core' ) .'</span></div>' : ''; ?>
							<?php echo ( $ap_size ) ? '<div class="meta-item"><h3>' . esc_html__( 'Area Size', 'sw_core' ) . '</h3> <span>'. esc_html( $ap_size ) .'</span></div>' : ''; ?>
							<?php echo ( $ap_garages ) ? '<div class="meta-item"><h3>' . esc_html__( 'Garages', 'sw_core' ) . '</h3> <span>'. esc_html( $ap_garages ) . esc_html__( ' Garages', 'sw_core' ) .'</span></div>' : ''; ?>
							<?php echo ( $ap_price ) ? '<div class="meta-item"><h3>' . esc_html__( 'Price', 'sw_core' ) . '</h3> <span>'. esc_html( $ap_price ) .'</span></div>' : ''; ?>
						</div>
					</div>
					<div class="clear"></div>
				</div>
			<?php endwhile; ?>
		</div>
	</div>	
</div>
<?php get_footer(); ?>