<?php
/**
 * Name: SW apartment Slider Widget
 * Description: A widget that serves as an slider for developing more advanced widgets.
 */
 
// Get gallery ID
function sw_get_apartment_gallery( $postid ){
	global $post;
	$gallery	  = get_post_meta( $postid, 'ap_gallery', true );
	$gallery_id = array();
	if( $gallery !== '' ){
		$gallery_id = explode( ',', $gallery );
	}
	
	$image_id 	 = get_post_thumbnail_id( $postid );
	array_unshift( $gallery_id, $image_id );
	$gallery_id = array_unique( $gallery_id );
	return $gallery_id;
}


if( !class_exists('SWG_Apartment') ) :
	add_action( 'widgets_init', 'SWG_Apartment' );
	function SWG_Apartment(){
		register_widget( 'SWG_Apartment' );
	}	 

	class SWG_Apartment extends WP_Widget {
	
	private $snumber = 1;
	function __construct() {

		/* Widget settings. */
		$widget_ops = array( 'classname' => 'SWG_Apartment', 'description' => __('Sw Apartment Widget', 'sw_core') );

		/* Widget control settings. */
		$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'SWG_Apartment' );

		/* Create the widget. */
		parent::__construct( 'SWG_Apartment', __('Sw Apartment Widget', 'sw_core'), $widget_ops, $control_ops );

		/* Register Taxonomy */
		add_action( 'init', array( $this, 'apartment_register' ), 2 );	
		add_action( 'admin_init', array( $this, 'apartment_init' ) );
		add_action( 'save_post', array( $this, 'apartment_save_meta' ), 10, 1 );
	
		/* Create Shortcode */
		add_shortcode( 'apartment', array( $this, 'TT_Shortcode' ) );
		add_filter( 'template_include', array( $this, 'sw_apartment_template_load' ) );

		/* Create Vc_map */
		if (class_exists('Vc_Manager')) {
			add_action( 'vc_before_init', array( $this, 'PR_integrateWithVC' ), 20 );
		}
		add_action( 'admin_enqueue_scripts', array( $this, 'sw_apartment_admin_settings_script' ) );
		add_action( 'wp_footer', array( $this, 'sw_footer_custom' ), 200 );

		/* Add ajax */
		add_action( 'wp_ajax_sw_apartment_ajax', array( $this, 'sw_apartment_ajax' ) );
		add_action( 'wp_ajax_nopriv_sw_apartment_ajax', array( $this, 'sw_apartment_ajax' ) );

	}
	
	/*
	** Generate ID
	*/
	public function generateID() {
		return 'sw_apartment_' . (int) $this->snumber++;
	}
	
	function sw_footer_custom(){
		if( is_singular( 'apartment' ) ) :
			global $post;
			if( count( sw_get_apartment_gallery( $post->ID ) ) ) :
				echo '<script>jQuery("a.gallery-single-item").fancybox();</script>';
			endif;
		endif;
	}
	
	function sw_apartment_admin_settings_script(){
		$current_screen =  isset( get_current_screen()->id ) ? get_current_screen()->id : '';	
		if( $current_screen === 'apartment_page_apartment-settings' || $current_screen === 'apartment'|| $current_screen === 'event' ){
			$args = array(
				'service_upload_img' 		=> esc_html__( 'Upload/Add image', 'sw_core' ),
				'service_upload_rmimg' 		=> esc_html__( 'Remove image', 'sw_core' ),
				'service_rmbutton' 			=> esc_html__( 'Remove', 'sw_core' ),
				'setting_media_title' 		=> esc_html__( "Choose an image", 'sw_core' ),
				'setting_text_message' 		=> esc_html__( "Sale price must less than main price", 'sw_core' ),
				'setting_media_button_text' => esc_html__( "Use image", 'sw_core' ),
				'setting_img_placehold' 	=> sw_placeholder_img_src()
			);	
			wp_enqueue_style( '_apartment_settings_style', SWURL . '/css/admin/style3.css', array(), null );
			wp_enqueue_media();
			wp_register_script( '_apartment_settings', SWURL . '/js/admin/admin3.min.js', array(), null, true );
			wp_localize_script( '_apartment_settings', 'setting_val', $args );
			wp_enqueue_script( '_apartment_settings' );
		}
	}
	
	function apartment_register() { 
		$labels = array(
			'name' => __('Apartment', 'sw_core'),
			'singular_name' => __('Apartment Item', 'sw_core'),
			'add_new' => __('Add New', 'sw_core'),
			'add_new_item' => __('Add New Item', 'sw_core'),
			'edit_item' => __('Edit Item', 'sw_core'),
			'new_item' => __('New Item', 'sw_core'),
			'view_item' => __('View Item', 'sw_core'),
			'search_items' => __('Search', 'sw_core'),
			'not_found' =>  __('Nothing found', 'sw_core'),
			'not_found_in_trash' => __('Nothing found in Trash'),
			'parent_item_colon' => ''
		);

		$args = array(
			'labels' => $labels,
			'public' => true,
			'has_archive' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			'menu_icon' => 'dashicons-portfolio',
			'rewrite' =>  true,
			'capability_type' => 'post',
			'hierarchical' => true,
			'menu_position' => 4,
			'supports' => array( 'title', 'thumbnail', 'editor' )
		  );


		register_post_type( 'apartment' , $args );
		register_taxonomy( 'apartment_cat', array( 'apartment' ), array( 'hierarchical' => true, 'label' => esc_html__( 'Categories Apartment', 'sw_core' ), 'singular_label' => esc_html__( 'Categories Apartment', 'sw_core' ), 'rewrite' => array( 'slug' => esc_html__( 'apartment_cat', 'sw_core' ) ) ) );
		register_taxonomy( 'apartment_tag', 'apartment', array(
			'hierarchical' => false, 
			'label' => esc_html__( 'Tags', 'sw_core' ), 
			'singular_name' => esc_html__( 'Tag', 'sw_core' ), 
			'rewrite' => array( 'slug' => esc_html__( 'apartment_tag', 'sw_core' ) ), 
			'query_var' => true
			)
		);
	}
	
	function apartment_init(){
		add_meta_box( __( 'apartment Options', 'sw_core' ), __( 'Apartment Meta', 'sw_core' ), array( $this, 'apartment_detail' ), 'apartment', 'normal', 'low' );
		add_meta_box( 'sw_apartment_gallery_meta', esc_html__( 'Apartment Gallery', 'sw_core' ), array( $this, 'sw_apartment_gallery_meta' ), 'apartment', 'side', 'low' );
	}
	
	function apartment_detail(){
		global $post;
		// Add an nonce field so we can check for it later.
		wp_nonce_field( 'apartment_save_meta', 'sw_apartment_plugin_nonce' );
		$ap_bedrooms 	 = get_post_meta( $post->ID, 'ap_bedrooms', true );
		$ap_bathrooms = get_post_meta( $post->ID, 'ap_bathrooms', true );
		$ap_size = get_post_meta( $post->ID, 'ap_size', true );
		$ap_garages = get_post_meta( $post->ID, 'ap_garages', true );
		$ap_price = get_post_meta( $post->ID, 'ap_price', true );
		$ap_price2 = get_post_meta( $post->ID, 'ap_price2', true );
	?>	
		<p><label><b><?php esc_html_e('Bedrooms', 'sw_core'); ?>:</b></label><br/>
			<input type ="text" name = "ap_bedrooms" value ="<?php echo esc_attr( $ap_bedrooms );?>" size="70%" /></p>
		<p><label><b><?php esc_html_e('Bathrooms', 'sw_core'); ?>:</b></label><br/>
			<input type ="text" name = "ap_bathrooms" value ="<?php echo esc_attr( $ap_bathrooms );?>" size="70%" /></p>
		<p><label><b><?php esc_html_e('Area Size', 'sw_core'); ?>:</b></label><br/>
			<input type ="text" name = "ap_size" value ="<?php echo esc_attr( $ap_size );?>" size="70%" /></p>
		<p><label><b><?php esc_html_e('Garages', 'sw_core'); ?>:</b></label><br/>
			<input type ="text" name = "ap_garages" value ="<?php echo esc_attr( $ap_garages );?>" size="70%" /></p>
		<p><label><b><?php esc_html_e('Price', 'sw_core'); ?>:</b></label><br/>
			<input type ="text" name = "ap_price" value ="<?php echo esc_attr( $ap_price );?>" size="70%" /></p>
		<p><label><b><?php esc_html_e('Price/m2', 'sw_core'); ?>:</b></label><br/>
			<input type ="text" name = "ap_price2" value ="<?php echo esc_attr( $ap_price2 );?>" size="70%" /></p>
	<?php 
	}
	
	/* Metabox galleries */
	function sw_apartment_gallery_meta(){
		global $post;
		wp_nonce_field( 'sw_apartment_save_meta', 'sw_apartment_gallery_nonce' );
		$gallery	 = get_post_meta( $post->ID, 'ap_gallery', true );
	?>
		<div class="apartment-gallery">
			<div class="gallery-append">
				<?php if( $gallery ) :  ?>
				<ul>
				<?php 
					$images = explode( ',', $gallery );
					foreach( $images as $key => $img ){
				?>
					<li><img src="<?php echo wp_get_attachment_thumb_url($img) ?>" alt="" id="<?php echo esc_attr( $img ); ?>"/><span class="gallery-remove" data-id="<?php echo esc_attr( $img ); ?>"></span></li>
				<?php	}	?>			
				</ul>
				<?php endif; ?>
			</div>
			<a href="javascript:void(0)" data-toggle="apartment_gallery"><?php echo esc_html__( 'Upload Gallery Images', 'sw_core' ); ?></a>
			<input type="hidden" name="ap_gallery" value="<?php echo esc_attr( $gallery ); ?>"/>		
		</div>
	<?php 
	}
	
	function apartment_save_meta( $post_id ){
		if ( ! isset( $_POST['sw_apartment_plugin_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( $_POST['sw_apartment_plugin_nonce'], 'apartment_save_meta' ) ) {
			return;
		}
		$list_meta = array( 'ap_bedrooms', 'ap_bathrooms', 'ap_size', 'ap_garages', 'ap_price', 'ap_price2' );
		foreach( $list_meta as $meta ){
			if( isset( $_POST[$meta] ) ){
				$my_data = $_POST[$meta];
				update_post_meta( $post_id, $meta, $my_data );
			}
		}
	}
	
	
	
	// Get template content
	function sw_apartment_template_load( $template ){
		// Food template check
		if( is_post_type_archive( 'apartment' ) || is_tax( 'apartment_cat' ) || is_tax( 'apartment_tag' ) ){
			$template = sw_core_override_check( 'sw-apartment/loop', 'archive-apartment' );
		}	
		if( is_singular( 'apartment' ) ){
			$template = sw_core_override_check( 'sw-apartment/single-apartment', 'single-apartment' );
		}

		return $template;
	}

	/* Add Script */
	public function Apartment_Script(){
		wp_register_script( 'isotope_script', SWURL . '/js/isotope.js',array(), null, true );
		wp_enqueue_script( 'isotope_script' );
		wp_register_script( 'apartment_script', SWURL . '/js/apartment.js',array(), null, true );
		wp_localize_script( 'apartment_script', 'ya_apartment', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
		wp_enqueue_script( 'apartment_script' );		
	}

	/**
	* VC Integrate
	**/
	function PR_integrateWithVC(){
		$terms = get_terms( 'apartment_cat', array( 'parent' => '', 'hide_empty' => false ) );
		$term = array( __( 'All Categories', 'sw_core' ) => '' );
		if( count( $terms )  > 0 ){
			foreach( $terms as $cat ){
				$term[$cat->name] = $cat -> term_id;
			}
		}
		vc_map( array(
			'name' =>  __( 'Sw apartment Slider', 'sw_core' ),
			'base' => 'apartment',
			"icon" => "icon-wpb-ytc",
			'category' => __( 'SW Core', 'sw_core' ),
			'class' => 'wpb_vc_wp_widget',
			'weight' => - 50,
			'description' => '',
			'params' => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Title", 'sw_core' ),
					"param_name" => "title",
					"admin_label" => true,
					"value" => '',
					"description" => __( "Title", 'sw_core' )
				 ),
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Description", 'sw_core' ),
					"param_name" => "description",
					"admin_label" => true,
					"value" => '',
					"description" => __( "Description", 'sw_core' )
				),
				 array(
					"type" => "multiselect",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Category", 'sw_core' ),
					"param_name" => "category",
					"admin_label" => true,
					"value" => $term,
					"description" => __( "Select Category", 'sw_core' )
				),
				
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number Of Post", 'sw_core' ),
					"param_name" => "numberposts",
					"admin_label" => true,
					"value" => 5,
					"description" => __( "Number Of Post", 'sw_core' )
				 ),				 
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number row per column", 'sw_core' ),
					"param_name" => "item_row",
					"admin_label" => true,
					"value" =>array(1,2,3),
					"description" => __( "Number row per column", 'sw_core' )
				 ),				 
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Order By", 'sw_core' ),
					"param_name" => "orderby",
					"admin_label" => true,
					"value" => array('Name' => 'name', 'Author' => 'author', 'Date' => 'date', 'Title' => 'title', 'Modified' => 'modified', 'Parent' => 'parent', 'ID' => 'ID', 'Random' =>'rand', 'Comment Count' => 'comment_count'),
					"description" => __( "Order By", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Order", 'sw_core' ),
					"param_name" => "order",
					"admin_label" => true,
					"value" => array('Descending' => 'DESC', 'Ascending' => 'ASC'),
					"description" => __( "Order", 'sw_core' )
				 ),
				array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns >1200px: ", 'sw_core' ),
					"param_name" => "columns",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns >1200px:", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns on 992px to 1199px:", 'sw_core' ),
					"param_name" => "columns1",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns on 992px to 1199px:", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns on 768px to 991px:", 'sw_core' ),
					"param_name" => "columns2",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns on 768px to 991px:", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns on 480px to 767px:", 'sw_core' ),
					"param_name" => "columns3",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns on 480px to 767px:", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Number of Columns in 480px or less than:", 'sw_core' ),
					"param_name" => "columns4",
					"admin_label" => true,
					"value" => array(1,2,3,4,5,6),
					"description" => __( "Number of Columns in 480px or less than:", 'sw_core' )
				 ),
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Speed", 'sw_core' ),
					"param_name" => "speed",
					"admin_label" => true,
					"value" => 1000,
					"description" => __( "Speed Of Slide", 'sw_core' )
				 ),
				 array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Auto Play", 'sw_core' ),
					"param_name" => "autoplay",
					"admin_label" => true,
					"value" => array( 'False' => 'false', 'True' => 'true' ),
					"description" => __( "Auto Play", 'sw_core' )
				 ),
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Interval", 'sw_core' ),
					"param_name" => "interval",
					"admin_label" => true,
					"value" => 5000,
					"description" => __( "Interval", 'sw_core' )
				 ),
				 array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __( "Total Items Slided", 'sw_core' ),
					"param_name" => "scroll",
					"admin_label" => true,
					"value" => 1,
					"description" => __( "Total Items Slided", 'sw_core' )
				 ),
			 	array(
					'type' => 'dropdown',
					'holder' => 'div',
					'heading' => __( 'Layout', 'sw_core' ),
					'param_name' => 'layout',
					"admin_label" => true,
					'value' => array(
						__( 'Layout Default','sw_core' ) => 'default',
						__( 'Layout Listing','sw_core' ) => 'layout1',			
					),
					'description' => sprintf( __( 'Select Layout', 'sw_core' ) )
				),	
				array(
					'type' => 'textfield',
					'heading' => __( 'Extra class name', 'sw_core' ),
					'param_name' => 'el_class',
					"admin_label" => true,
					'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_core' )
				),
			)
		) );
	}


	/* Add ajax */
	function sw_apartment_ajax(){
		$catid 		= (isset($_POST['catid'])   && $_POST['catid'] != '' ) ? $_POST['catid'] : '';
		$page 		= (isset($_POST['page'])    && $_POST['page']> 0 ) ? $_POST['page'] : 0;
		$length     = isset( $instance['length'] )      	? intval($instance['length']) : 13;
		$attributes = (isset($_POST['attributes'])    && $_POST['attributes'] != '' ) ? $_POST['attributes'] : '';
		$number 	= (isset($_POST['numb'])    && $_POST['numb']>0) ? $_POST['numb'] : 0;
		$orderby 	= (isset($_POST['orderby']) && $_POST['orderby'] != '' ) ? $_POST['orderby'] : '';
		$order 		= (isset($_POST['order']) && $_POST['order'] != '' ) ? $_POST['order'] : '';
		$style 		= (isset($_POST['style']) && $_POST['style'] != '' ) ? $_POST['style'] : '';
		$layout 	= (isset($_POST['layout']) && $_POST['layout'] != '' ) ? $_POST['layout'] : '';
		$paged 		= (get_query_var( 'paged' )) ? get_query_var( 'paged' ) : 1;
		$categories = explode( ',', $catid );
		$args = array(
			'post_type'		=> 'apartment',
			'tax_query'		=> array(
				array(
					'taxonomy'	=> 'apartment_cat',
					'field'		=> 'term_id',
					'terms' 		=> $categories
				)
			),
			'posts_per_page' => $number,
			'orderby'		 => $orderby,
			'order'			 => $order,
			'offset'		 => $number*($page-1)
		);

		$output = '';
		$query = new wp_query( $args ); 

		while( $query -> have_posts() ) : $query -> the_post();
		global $post;
		
			
		
		$ap_bedrooms 	 = get_post_meta( $post->ID, 'ap_bedrooms', true );
		$ap_bathrooms = get_post_meta( $post->ID, 'ap_bathrooms', true );
		$term_str = '';
		foreach( $pterms as $key => $term ){
			$term_str .= $term ->term_id. ' ';
		}
		$img = '';
			if( $layout == 'layout1' ){
			?>
				<li class="grid-item <?php echo $attributes.' '.esc_attr( $term_str ). ' ' ?>">
					<div class="item-content">
						<?php 
							$feat_image_url = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
							if ( $feat_image_url ){ 
						?>
						<div class="item-img">
							<a href="<?php echo get_permalink($post->ID)?>" title="<?php the_title_attribute(); ?>">
							<?php 								
								$width  = 370;
								$height = 400;
								$image = sw_image_resize( $feat_image_url, $width, $height, true );
								echo '<img src="'. esc_url( $image['url'] ) .'" alt="'. esc_attr( $post->post_title ) .'">';
							?>
							</a>
						</div>
						<?php } ?>
						<div class="entry-content">
							<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
							<div class="description">
								<?php 										
									$content = wp_trim_words($post->post_content, $length, '...');						
									echo $content;
								?>
							</div>
							<div class="entry-meta clearfix">
								<?php echo ( $ap_bedrooms ) ? '<div class="meta-item"><p>' . esc_html__( 'Bedrooms', 'sw_core' ) . '</p> <span>'. esc_html( $ap_bedrooms ) .'</span></div>' : ''; ?>
								<?php echo ( $ap_bathrooms ) ? '<div class="meta-item"><p>' . esc_html__( 'Bathrooms', 'sw_core' ) . '</p> <span>'. esc_html( $ap_bathrooms ) .'</span></div>' : ''; ?>
							</div>
						</div>
					</div>
				</li>
			
				<?php }else{ ?>
				<li class="grid-item <?php echo $attributes.' '.esc_attr( $term_str ); ?>">
					<div class="item-content">
						<?php 
							$feat_image_url = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
							if ( $feat_image_url ){ 
						?>
						<div class="item-img">
							<a href="<?php echo get_permalink($post->ID)?>" title="<?php the_title_attribute(); ?>">
							<?php 								
								$width  = 795;
								$height = 480;
								$image = sw_image_resize( $feat_image_url, $width, $height, true );
								echo '<img src="'. esc_url( $image['url'] ) .'" alt="'. esc_attr( $post->post_title ) .'">';
							?>
							</a>
						</div>
						<?php } ?>
						<div class="entry-content">
							<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
							<div class="description">
								<?php 										
									$content = wp_trim_words($post->post_content, $length, '...');						
									echo $content;
								?>
							</div>
							<div class="entry-meta clearfix">
								<?php echo ( $ap_bedrooms ) ? '<div class="meta-item col-md-6 col-sm-6 col-xs12"><p>' . esc_html__( 'Bedrooms', 'sw_core' ) . '</p> <span>'. esc_html( $ap_bedrooms ) .'</span></div>' : ''; ?>
								<?php echo ( $ap_bathrooms ) ? '<div class="meta-item col-md-6 col-sm-6 col-xs12"><p>' . esc_html__( 'Bathrooms', 'sw_core' ) . '</p> <span>'. esc_html( $ap_bathrooms ) .'</span></div>' : ''; ?>
							</div>
							<div class="readmore"><a href="<?php echo get_permalink($post->ID)?>" title="<?php the_title_attribute(); ?>"><i class="fa fa-angle-right" aria-hidden="true"></i></a></div>
						</div>
					</div>
				</li>
			<?php 
			}
		endwhile;
		wp_reset_postdata();
		exit();
	}
	
	/**
	* Add Shortcode
	**/
	function TT_Shortcode( $atts,$content = null ){
		extract(shortcode_atts(array(
			'el_class'=> '',
			'title'=> '',
			'description' => '',
			'category'=> '',
			'orderby' => 'name',
			'order' => 'DESC',
			'numberposts' => 5,
			'item_row' => 1,
			'columns' => 4,
			'columns1' => 4,
			'columns2' => 3,
			'columns3' => 2,
			'columns4' => 1,
			'speed' => 1000,
			'autoplay' => 'false',
			'interval' => 5000,
			'layout'  => 'default',
			'scroll' => 1
		 ),$atts));
		$this->Apartment_Script();
		ob_start();		
		if( $layout == 'default' ){
			include( sw_core_override_check( 'sw-apartment/themes/', 'default' ) );	
		}else{
			include( sw_core_override_check( 'sw-apartment/themes/', 'layout1' ) );	
		}
		$content = ob_get_clean();
		
		return $content;
	}
		
	/**
	 * Display the widget on the screen.
	 */
	public function widget( $args, $instance ) {
		wp_reset_postdata();
		extract($args);
		$title = apply_filters( 'widget_title', empty( $instance['title1'] ) ? '' : $instance['title1'], $instance, $this->id_base );
		$description1 = apply_filters( 'widget_description', empty( $instance['description1'] ) ? '' : $instance['description1'], $instance, $this->id_base );
		echo $before_widget;
		if ( !empty( $title ) && !empty( $description1 ) ) { echo $before_title . $title . $after_title . '<h5 class="category_description clearfix">' . $description1 . '</h5>'; }
		else if (!empty( $title ) && $description1==NULL ){ echo $before_title . $title . $after_title; }
		
		if (!isset($instance['category'])){
			$instance['category'] = 0;
		}
		extract($instance);

		if ( !array_key_exists('widget_template', $instance) ){
			$instance['widget_template'] = 'default';
		}
		
		if ( $tpl = $this->getTemplatePath( $instance['widget_template'] ) ){ 
			$widget_id = $args['widget_id'];		
			include $tpl;
		}
				
		/* After widget (defined by themes). */
		echo $after_widget;
	}    

	protected function getTemplatePath($tpl='default', $type=''){
		$file = '/'.$tpl.$type.'.php';
		$dir =realpath(dirname(__FILE__)).'/themes';
		
		if ( file_exists( $dir.$file ) ){
			return $dir.$file;
		}
		
		return $tpl=='default' ? false : $this->getTemplatePath('default', $type);
	}
	
	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		// strip tag on text field
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['description'] = strip_tags( $new_instance['description'] );
		// int or array
		if ( array_key_exists('category', $new_instance) ){
			if ( is_array($new_instance['category']) ){
				$instance['category'] = array_map( 'intval', $new_instance['category'] );
			}
		}
		
		if ( array_key_exists('orderby', $new_instance) ){
			$instance['orderby'] = strip_tags( $new_instance['orderby'] );
		}

		if ( array_key_exists('order', $new_instance) ){
			$instance['order'] = strip_tags( $new_instance['order'] );
		}

		if ( array_key_exists('numberposts', $new_instance) ){
			$instance['numberposts'] = intval( $new_instance['numberposts'] );
		}
		if ( array_key_exists('item_row', $new_instance) ){
			$instance['item_row'] = intval( $new_instance['item_row'] );
		}
		if ( array_key_exists('length', $new_instance) ){
			$instance['length'] = intval( $new_instance['length'] );
		}
		
		if ( array_key_exists('columns', $new_instance) ){
			$instance['columns'] = intval( $new_instance['columns'] );
		}
		if ( array_key_exists('columns1', $new_instance) ){
			$instance['columns1'] = intval( $new_instance['columns1'] );
		}
		if ( array_key_exists('columns2', $new_instance) ){
			$instance['columns2'] = intval( $new_instance['columns2'] );
		}
		if ( array_key_exists('columns3', $new_instance) ){
			$instance['columns3'] = intval( $new_instance['columns3'] );
		}
		if ( array_key_exists('columns4', $new_instance) ){
			$instance['columns4'] = intval( $new_instance['columns4'] );
		}		
		if ( array_key_exists('interval', $new_instance) ){
			$instance['interval'] = intval( $new_instance['interval'] );
		}
		if ( array_key_exists('speed', $new_instance) ){
			$instance['speed'] = intval( $new_instance['speed'] );
		}
		if ( array_key_exists('start', $new_instance) ){
			$instance['start'] = intval( $new_instance['start'] );
		}
		if ( array_key_exists('scroll', $new_instance) ){
			$instance['scroll'] = intval( $new_instance['scroll'] );
		}	
		if ( array_key_exists('autoplay', $new_instance) ){
			$instance['autoplay'] = strip_tags( $new_instance['autoplay'] );
		}
		$instance['widget_template'] = strip_tags( $new_instance['widget_template'] );
				
					
				
		return $instance;
	}

	function category_select( $field_name, $opts = array(), $field_value = null ){
		$default_options = array(
				'multiple' => true,
				'disabled' => false,
				'size' => 5,
				'class' => 'widefat',
				'required' => false,
				'autofocus' => false,
				'form' => false,
		);
		$opts = wp_parse_args($opts, $default_options);
	
		if ( (is_string($opts['multiple']) && strtolower($opts['multiple'])=='multiple') || (is_bool($opts['multiple']) && $opts['multiple']) ){
			$opts['multiple'] = 'multiple';
			if ( !is_numeric($opts['size']) ){
				if ( intval($opts['size']) ){
					$opts['size'] = intval($opts['size']);
				} else {
					$opts['size'] = 5;
				}
			}
		} else {
			// is not multiple
			unset($opts['multiple']);
			unset($opts['size']);
			if (is_array($field_value)){
				$field_value = array_shift($field_value);
			}
			if (array_key_exists('allow_select_all', $opts) && $opts['allow_select_all']){
				unset($opts['allow_select_all']);
				$allow_select_all = '<option value="0">All Categories</option>';
			}
		}
	
		if ( (is_string($opts['disabled']) && strtolower($opts['disabled'])=='disabled') || is_bool($opts['disabled']) && $opts['disabled'] ){
			$opts['disabled'] = 'disabled';
		} else {
			unset($opts['disabled']);
		}
	
		if ( (is_string($opts['required']) && strtolower($opts['required'])=='required') || (is_bool($opts['required']) && $opts['required']) ){
			$opts['required'] = 'required';
		} else {
			unset($opts['required']);
		}
	
		if ( !is_string($opts['form']) ) unset($opts['form']);
	
		if ( !isset($opts['autofocus']) || !$opts['autofocus'] ) unset($opts['autofocus']);
	
		$opts['id'] = $this->get_field_id($field_name);
	
		$opts['name'] = $this->get_field_name($field_name);
		if ( isset($opts['multiple']) ){
			$opts['name'] .= '[]';
		}
		$select_attributes = '';
		foreach ( $opts as $an => $av){
			$select_attributes .= "{$an}=\"{$av}\" ";
		}
		
		$categories = get_terms('apartment_cat');
		//print '<pre>'; var_dump($categories);
		// if (!$templates) return '';
		$all_category_ids = array();
		foreach ($categories as $cat) $all_category_ids[] = $cat->term_id;
		
		$is_valid_field_value = is_numeric($field_value) && in_array($field_value, $all_category_ids);
		if (!$is_valid_field_value && is_array($field_value)){
			$intersect_values = array_intersect($field_value, $all_category_ids);
			$is_valid_field_value = count($intersect_values) > 0;
		}
		if (!$is_valid_field_value){
			$field_value = '0';
		}
	
		$select_html = '<select ' . $select_attributes . '>';
		if (isset($allow_select_all)) $select_html .= $allow_select_all;
		foreach ($categories as $cat){
			$select_html .= '<option value="' . $cat->term_id . '"';
			if ($cat->term_id == $field_value || (is_array($field_value)&&in_array($cat->term_id, $field_value))){ $select_html .= ' selected="selected"';}
			$select_html .=  '>'.$cat->name.'</option>';
		}
		$select_html .= '</select>';
		return $select_html;
	}
	

	/**
	 * Displays the widget settings controls on the widget panel.
	 * Make use of the get_field_id() and get_field_name() function
	 * when creating your form elements. This handles the confusing stuff.
	 */
	public function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array();
		$instance = wp_parse_args( (array) $instance, $defaults ); 		
						 
		$title = isset( $instance['title'] )    ? 	strip_tags($instance['title']) : '';
		$description = isset( $instance['description'] )    ? 	strip_tags($instance['description']) : '';
		$categoryid = isset( $instance['category'] )    	? $instance['category'] : 0;
		$orderby    = isset( $instance['orderby'] )     	? strip_tags($instance['orderby']) : 'ID';
		$order      = isset( $instance['order'] )       	? strip_tags($instance['order']) : 'ASC';
		$number     = isset( $instance['numberposts'] ) 	? intval($instance['numberposts']) : 5;
		$item_row   = isset( $instance['item_row'] )    	? intval($instance['item_row']) : 1;
		$length     = isset( $instance['length'] )      	? intval($instance['length']) : 25;
		$columns    = isset( $instance['columns'] )      	? intval($instance['columns']) : '';
		$columns1   = isset( $instance['columns1'] )      	? intval($instance['columns1']) : '';
		$columns2   = isset( $instance['columns2'] )      	? intval($instance['columns2']) : '';
		$columns3   = isset( $instance['columns3'] )      	? intval($instance['columns3']) : '';
		$columns4   = isset( $instance['columns4'] )      	? intval($instance['columns4']) : '';
		$autoplay   = isset( $instance['autoplay'] )      	? strip_tags($instance['autoplay']) : 'true';
		$interval   = isset( $instance['interval'] )      	? intval($instance['interval']) : 5000;
		$speed     	= isset( $instance['speed'] )      		? intval($instance['speed']) : 1000;
		$scroll     = isset( $instance['scroll'] )      	? intval($instance['scroll']) : 1;
		$widget_template   = isset( $instance['widget_template'] ) ? strip_tags($instance['widget_template']) : 'default';
									 
								 
		?>		
			</p> 
				<div style="background: Blue; color: white; font-weight: bold; text-align:center; padding: 3px"> * Data Config * </div>
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>"
					type="text"	value="<?php echo esc_attr($title); ?>" />
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('description'); ?>"><?php _e('Description', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>"
					type="text"	value="<?php echo esc_attr($description); ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('category'); ?>"><?php _e('Category ID', 'sw_core')?></label>
				<br />
				<?php echo $this->category_select('category', array('allow_select_all' => true), $categoryid); ?>
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('orderby'); ?>"><?php _e('Orderby', 'sw_core')?></label>
				<br />
				<?php $allowed_keys = array('name' => 'Name', 'author' => 'Author', 'date' => 'Date', 'title' => 'Title', 'modified' => 'Modified', 'parent' => 'Parent', 'ID' => 'ID', 'rand' =>'Rand', 'comment_count' => 'Comment Count'); ?>
				<select class="widefat"
					id="<?php echo $this->get_field_id('orderby'); ?>"
					name="<?php echo $this->get_field_name('orderby'); ?>">
					<?php
					$option ='';
					foreach ($allowed_keys as $value => $key) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $orderby){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p>

			<p>
				<label for="<?php echo $this->get_field_id('order'); ?>"><?php _e('Order', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('order'); ?>" name="<?php echo $this->get_field_name('order'); ?>">
					<option value="DESC" <?php if ($order=='DESC'){?> selected="selected"
					<?php } ?>>
						<?php _e('Descending', 'sw_core')?>
					</option>
					<option value="ASC" <?php if ($order=='ASC'){?> selected="selected"	<?php } ?>>
						<?php _e('Ascending', 'sw_core')?>
					</option>
				</select>
			</p>

			<p>
				<label for="<?php echo $this->get_field_id('numberposts'); ?>"><?php _e('Number of Posts', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('numberposts'); ?>" name="<?php echo $this->get_field_name('numberposts'); ?>"
					type="text"	value="<?php echo esc_attr($number); ?>" />
			</p>

			<?php $row_number = array( '1' => 1, '2' => 2, '3' => 3 ); ?>
			<p>
				<label for="<?php echo $this->get_field_id('item_row'); ?>"><?php _e('Number row per column:  ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('item_row'); ?>"
					name="<?php echo $this->get_field_name('item_row'); ?>">
					<?php
					$option ='';
					foreach ($row_number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $item_row){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 

			<p>
				<label for="<?php echo $this->get_field_id('length'); ?>"><?php _e('Excerpt length (in words): ', 'sw_core')?></label>
				<br />
				<input class="widefat"
					id="<?php echo $this->get_field_id('length'); ?>" name="<?php echo $this->get_field_name('length'); ?>" type="text" 
					value="<?php echo esc_attr($length); ?>" />
			</p>  
			<?php $number = array('1' => 1, '2' => 2, '3' => 3, '4' => 4, '5' => 5, '6' => 6); ?>
			<p>
				<label for="<?php echo $this->get_field_id('columns'); ?>"><?php _e('Number of Columns >1200px: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns'); ?>"
					name="<?php echo $this->get_field_name('columns'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('columns1'); ?>"><?php _e('Number of Columns on 992px to 1199px: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns1'); ?>"
					name="<?php echo $this->get_field_name('columns1'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns1){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('columns2'); ?>"><?php _e('Number of Columns on 768px to 991px: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns2'); ?>"
					name="<?php echo $this->get_field_name('columns2'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns2){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('columns3'); ?>"><?php _e('Number of Columns on 480px to 767px: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns3'); ?>"
					name="<?php echo $this->get_field_name('columns3'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns3){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('columns4'); ?>"><?php _e('Number of Columns in 480px or less than: ', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('columns4'); ?>"
					name="<?php echo $this->get_field_name('columns4'); ?>">
					<?php
					$option ='';
					foreach ($number as $key => $value) :
						$option .= '<option value="' . $value . '" ';
						if ($value == $columns4){
							$option .= 'selected="selected"';
						}
						$option .=  '>'.$key.'</option>';
					endforeach;
					echo $option;
					?>
				</select>
			</p> 
			
			<p>
				<label for="<?php echo $this->get_field_id('autoplay'); ?>"><?php _e('Auto Play', 'sw_core')?></label>
				<br />
				<select class="widefat"
					id="<?php echo $this->get_field_id('autoplay'); ?>" name="<?php echo $this->get_field_name('autoplay'); ?>">
					<option value="false" <?php if ($autoplay=='false'){?> selected="selected"
					<?php } ?>>
						<?php _e('False', 'sw_core')?>
					</option>
					<option value="true" <?php if ($autoplay=='true'){?> selected="selected"	<?php } ?>>
						<?php _e('True', 'sw_core')?>
					</option>
				</select>
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('interval'); ?>"><?php _e('Interval', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('interval'); ?>" name="<?php echo $this->get_field_name('interval'); ?>"
					type="text"	value="<?php echo esc_attr($interval); ?>" />
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('speed'); ?>"><?php _e('Speed', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('speed'); ?>" name="<?php echo $this->get_field_name('speed'); ?>"
					type="text"	value="<?php echo esc_attr($speed); ?>" />
			</p>
			
			
			<p>
				<label for="<?php echo $this->get_field_id('scroll'); ?>"><?php _e('Total Items Slided', 'sw_core')?></label>
				<br />
				<input class="widefat" id="<?php echo $this->get_field_id('scroll'); ?>" name="<?php echo $this->get_field_name('scroll'); ?>"
					type="text"	value="<?php echo esc_attr($scroll); ?>" />
			</p>
			
			<p>
				<label for="<?php echo $this->get_field_id('widget_template'); ?>"><?php _e("Template", 'sw_core')?></label>
				<br/>
				
				<select class="widefat" id="<?php echo $this->get_field_id('widget_template'); ?>"	name="<?php echo $this->get_field_name('widget_template'); ?>">
					<option value="default" <?php if ($widget_template=='default'){?> selected="selected"
					<?php } ?>>
						<?php _e('Default', 'sw_core')?>
					</option>			
				</select>
			</p>           
		<?php
		}	
	}
endif;
?>