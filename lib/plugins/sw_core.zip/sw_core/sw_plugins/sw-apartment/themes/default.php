<?php 
	$this->Apartment_Script();
	if( !is_array( $category ) && count( $category ) == 0 ){
		return ;
	}
	$attributes = 'col-lg-12 col-md-12 col-sm-12 col-xs-12'; 
	
	$args = array(
		'post_type' => 'apartment',
		'tax_query' => array(
			array(
				'taxonomy'	=> 'apartment_cat',
				'field' 	=> 'term_id',
				'terms'		=> $category
			)
		),
		'orderby'	=> $orderby,
		'order'	=> $order,
		'showposts' => $numberposts
	);
	$query = new WP_Query( $args );
	$max_page = $query -> max_num_pages;
	$pf_id = 'apartment' . time();
	if( $query->have_posts() ) :
?>
<div id="<?php echo esc_attr( $pf_id ); ?>" class="apartment-portfolio" data-layout="layout1" data-categories="<?php echo implode( ',', $category ); ?>" data-max_page="<?php echo esc_attr( $max_page ); ?>" data-number="<?php echo esc_attr( $numberposts ) ?>" data-length="<?php echo esc_attr( $length ) ?>" data-orderby="<?php echo esc_attr( $orderby ) ?>" data-order="<?php echo esc_attr( $order ) ?>" data-style="fitRows" data-attributes="<?php echo esc_attr( $attributes ) ?>">
	<?php if( $title != '' ){?>
		<div class="block-title clearfix">
			<h3><?php echo $title; ?></h3>
		</div>
	<?php } ?>
	<!-- Tab  -->
	<div class="apartment-tab">
		<button class="button-collapse collapsed" type="button" data-toggle="collapse" data-target="#<?php echo 'tab_'.$pf_id; ?>" aria-expanded="false"></button>
		<ul id="tab_<?php echo esc_attr( $pf_id ); ?>">
		<?php
		    $f = '';
			foreach( $category as $key => $cat_id ){
				$cat = get_term_by( 'term_id', $cat_id, 'apartment_cat' );
				if($key == 0) {
				   $f = $cat->term_id;
				}
				?>
				<li <?php if($key == 0):?> class="selected li_apartment"<?php else: ?>class="li_apartment"<?php endif; ?> data-apartment-filter=".<?php echo $cat->term_id; ?>"><?php echo esc_html( $cat -> name ); ?></li>
				<?php
			}
		?>
		</ul>
	</div>
	<!-- Container -->
	<div class="apartment-container">
		<ul id="container_<?php echo esc_attr( $pf_id ); ?>" class="project-content row clearfix" >
		<?php
			while( $query -> have_posts() ) : $query -> the_post();
			global $post;			
			$ap_bedrooms 	 = get_post_meta( $post->ID, 'ap_bedrooms', true );
			$ap_bathrooms = get_post_meta( $post->ID, 'ap_bathrooms', true );
			$ap_size = get_post_meta( $post->ID, 'ap_size', true );
			$ap_garages = get_post_meta( $post->ID, 'ap_garages', true );
			$ap_price = get_post_meta( $post->ID, 'ap_price', true );
			$ap_price2 = get_post_meta( $post->ID, 'ap_price2', true );
			$pterms	   	= get_the_terms( $post->ID, 'apartment_cat' );
			$term_str  = '';
			if( count($pterms) > 0 ){
				foreach( $pterms as $key => $term ){
					$term_str .= $term->term_id . ' ';
				}
			}	
			$img = '';
			$apartmentClass = '';
			if($f != $term_str) {
				$apartmentClass = 'first-apartment';
			}
		?>
				<li class="grid-item <?php echo $apartmentClass.' '.$attributes.' '.esc_attr( $term_str ); ?>" >
					<div class="plans-content">
						<div class="entry-content">
							<h3 class="titles"><?php the_title(); ?></h3>
							<div class="description">
								<?php 										
									$content = wp_trim_words($post->post_content, $length, '');						
									echo $content;
								?>
							</div>
							<div class="entry-meta clearfix">
								<?php echo ( $ap_bedrooms ) ? '<div class="meta-item"><label>' . esc_html__( 'Bedrooms', 'sw_core' ) . '</label> <span>'. esc_html( $ap_bedrooms ) .'</span></div>' : ''; ?>
								<?php echo ( $ap_bathrooms ) ? '<div class="meta-item"><label>' . esc_html__( 'Bathrooms', 'sw_core' ) . '</label> <span>'. esc_html( $ap_bathrooms ) .'</span></div>' : ''; ?>
								<?php echo ( $ap_size ) ? '<div class="meta-item"><label>' . esc_html__( 'Area Size', 'sw_core' ) . '</label> <span>'. esc_html( $ap_size ) .'</span></div>' : ''; ?>
								<?php echo ( $ap_garages ) ? '<div class="meta-item"><label>' . esc_html__( 'Garages', 'sw_core' ) . '</label> <span>'. esc_html( $ap_garages ) .'</span></div>' : ''; ?>
								<?php echo ( $ap_price ) ? '<div class="meta-item"><label>' . esc_html__( 'Price', 'sw_core' ) . '</label> <span>'. esc_html( $ap_price ) .'</span></div>' : ''; ?>
								<?php echo ( $ap_price2 ) ? '<div class="meta-item"><label> </label> <span>'. esc_html( $ap_price2 ) .'</span></div>' : ''; ?>
							</div>
							<div class="a-visit"><?php esc_html_e( "Schedule a visit", 'sw_core' )?></div>
						</div>
						<?php 
							$feat_image_url = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
							if ( $feat_image_url ){ 
						?>
						<div class="item-img">
							<a href="<?php echo get_permalink($post->ID)?>" title="<?php the_title_attribute(); ?>">
							<?php 								
								$width  = 704;
								$height = 377;
								$image = sw_image_resize( $feat_image_url, $width, $height, true );
								echo '<img src="'. esc_url( $image['url'] ) .'" alt="'. esc_attr( $post->post_title ) .'">';
							?>
							</a>
						</div>
						<?php } ?>
					</div>
				</li>
		<?php 
			endwhile;
			wp_reset_postdata();
		?>
		</ul>
	</div>
</div>
<?php endif; ?>